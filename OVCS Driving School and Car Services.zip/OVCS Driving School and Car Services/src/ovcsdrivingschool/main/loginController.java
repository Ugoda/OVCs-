/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ovcsdrivingschool.main;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

/**
 *
 * @author Nando
 */
public class loginController implements Initializable {

    @FXML
    private VBox vbox;
    
    private Parent fxml, fxmll;
    @FXML
    private JFXButton signUp_btn;
    @FXML
    private JFXButton signIn_btn;
    
    //this is the code that animates the login screen, it moves to the right initially
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        TranslateTransition x = new TranslateTransition(Duration.seconds(1), vbox);
        x.setToX(vbox.getLayoutX() * 32);
        x.play();
        x.setOnFinished((e)->{
            try {
                fxml = FXMLLoader.load(getClass().getResource("SignIn.fxml"));
                vbox.getChildren().removeAll();
                vbox.getChildren().setAll(fxml);
            } catch (IOException ex) {
                Logger.getLogger(loginController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }    
    //it animates to the left if you want to sign up/ register an account
    //it then calls the signup gui
    @FXML
    private void openSignUp(ActionEvent event) {
        TranslateTransition x = new TranslateTransition(Duration.seconds(1), vbox);
        x.setToX(14);
        x.play();
        x.setOnFinished((e)->{
            try {
                fxml = FXMLLoader.load(getClass().getResource("SignUP.fxml"));
                vbox.getChildren().removeAll();
                vbox.getChildren().setAll(fxml);
            } catch (IOException ex) {
                Logger.getLogger(loginController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }
    
      //it animates to the right if you want to sign in/ login
    //it then calls the sigin gui
    @FXML
    private void openSignIn(ActionEvent event) {
        TranslateTransition x = new TranslateTransition(Duration.seconds(1), vbox);
        x.setToX(vbox.getLayoutX() * 32);
        x.play();
        x.setOnFinished((e)->{
            try {
                fxml = FXMLLoader.load(getClass().getResource("SignIn.fxml"));
                vbox.getChildren().removeAll();
                vbox.getChildren().setAll(fxml);
            } catch (IOException ex) {
                Logger.getLogger(loginController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }
    
}
