/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ovcsdrivingschool.main;

import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import ovcs.database.model.SignUpModel;

/**
 * FXML Controller class
 *
 * @author Nando
 */
public class SignUPController implements Initializable {
SignUpModel model = new SignUpModel();
    @FXML
    private TextField usr;
    @FXML
    private PasswordField pwd;
    @FXML
    private JFXButton clr_btn;
    @FXML
    private JFXButton reg_btn;
    @FXML
    private PasswordField pwd_confirm;
    @FXML
    private Label pwd_errorMSG;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }    

    @FXML
    private void clear() {
        usr.setText(null);
        pwd.setText(null);
        pwd_confirm.setText(null);
        pwd_errorMSG.setText(null);
    }

    @FXML
    private void register() {
        String username = usr.getText();
        String password = pwd_confirm.getText();
        String pass = pwd.getText();
        if(pass.equals(password)){
            try {
                model.signUp(username, password);
            } catch (Exception ex) {
                Logger.getLogger(SignUPController.class.getName()).log(Level.SEVERE, null, ex);
            }    
        }
        else{
            pwd_errorMSG.setText("Passwords don't match!");
        }
        
    }
    
}
