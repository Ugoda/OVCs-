
package ovcsdrivingschool.main;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import ovcs.database.model.LoginModel;
import ovcsdrivingschool.controlpanel.CpanelBackupController;



public class SignInController implements Initializable {

    //The login model models how login works
    //it is called here to be used by the login controller
    LoginModel loginModel = new LoginModel();
    @FXML
    private TextField usr;
    @FXML
    private PasswordField pwd;
    @FXML
    private JFXButton loginBtn;
    
    private static String username;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    //this clears the data that has been entered by the user
    @FXML
    private void clear(ActionEvent event) {
        usr.setText(null);
        pwd.setText(null);
    }

    //this method controlls the signin, it uses the login model by parsing through the parameters username and password to login model
    //login model will use the parameters to check if they are in the database, if that is true it will then allow the user to login
    @FXML
    public void signIn(ActionEvent event) {

        try {
            //password and username are parsed into the method isLogin to check if they are in the database,
            //if they do exist in the database it then returns true
            if(loginModel.isLogin(usr.getText(), pwd.getText()) == true) {
                //when they are true it closes the login stage/panel and try to open the control panel
                Stage stage = (Stage)this.loginBtn.getScene().getWindow();
                username = usr.getText();
                getUsername();
                stage.close();
                //control panel is called after closing the sign-in screen
                controlPanel();
            }
            //if the info doesn't exist in the database, then the app remains the same, it doesn't allow you to log in
            else{
                Alert alert = new Alert(Alert.AlertType.ERROR, "Wrong Credentials Entered, try again");
                alert.showAndWait();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

  //this gets the username once you have logged-in
  //we use this info in the control panel controller
  public String getUsername(){
      return username;
  }
  //after checking the parameters and returning true, this method creates the panel for the control panel, it calls the controller class and its css file
   private void controlPanel(){
       
      try{
                    Stage drivingSchool = new Stage();
                    FXMLLoader drivingLoader = new FXMLLoader();
                    Parent gamerRoot = (Parent)drivingLoader.load(getClass().getResource("/ovcsdrivingschool/controlpanel/cpanelBackup.fxml").openStream());

                    CpanelBackupController control = (CpanelBackupController)drivingLoader.getController();

                    Scene scene = new Scene(gamerRoot);
                   
                    //scene.getStylesheets().setAll(getClassLoader().getResource("/ovcsdrivingschool/controlpanel/controlpanel.css").toExternalForm());
                    scene.getStylesheets().setAll(getClass().getResource("/ovcsdrivingschool/controlpanel/controlpanel.css").toExternalForm());
       
                    drivingSchool.setScene(scene);
                    
                
                    drivingSchool.show();
                }
                catch(IOException ex){
                    ex.printStackTrace();
                }
   }
  
}
