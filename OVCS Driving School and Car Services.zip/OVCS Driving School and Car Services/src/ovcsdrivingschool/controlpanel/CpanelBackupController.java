
package ovcsdrivingschool.controlpanel;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import ovcs.databae.connection.DBConnection;
import ovcsdrivingschool.main.SignInController;
import ovcsdrivingschool.main.loginController;


public class CpanelBackupController implements Initializable {

    @FXML
    private Text username;
    @FXML
    private HBox dashboard_btn;
    @FXML
    private HBox viewEmployees_btn;
    @FXML
    private HBox viewCars_btn;
    @FXML
    private HBox tracking_btn;
    @FXML
    private HBox bookTest_btn;
    @FXML
    private HBox payment_btn;
    @FXML
    private HBox invoices_btn;
    @FXML
    private HBox reports_btn;
    @FXML
    private HBox settings_btn;
    @FXML
    private HBox customer_support_btn;
    @FXML
    private AnchorPane home_pane;
    @FXML
    private AnchorPane viewEmployees_Pane;
    @FXML
    private TableColumn<EmployeeData, String> empNumbe;
    @FXML
    private TableColumn<EmployeeData, String> fname;
    @FXML
    private TableColumn<EmployeeData, String> lname;
    @FXML
    private TableColumn<EmployeeData, String> email;
    @FXML
    private TableColumn<EmployeeData, String> duties;
    @FXML
    private TableColumn<EmployeeData, String> dob;
    @FXML
    private TableView<EmployeeData> employees_table;
    @FXML
    private AnchorPane viewCars_Pane;
    @FXML
    private Button viewCars;
    @FXML
    private Button addCars;
    @FXML
    private Button deleteCars;
    @FXML
    private AnchorPane bookTest_Pane;
    @FXML
    private JFXButton restart;
    @FXML
    private JFXButton addTest;
    @FXML
    private JFXTextField fname_test;
    @FXML
    private JFXTextField lname_test;
    @FXML
    private JFXTextField email_test;
    @FXML
    private JFXTextField id_test;
    @FXML
    private JFXButton loadEmp_btn;
    @FXML
    private TableView<CarsData> carsDataTable;
    @FXML
    private TableColumn<CarsData, String> model;
    @FXML
    private TableColumn<CarsData, String> type;
    @FXML
    private TableColumn<CarsData, String> bookings;
    @FXML
    private TableColumn<CarsData, String> doa;
    @FXML
    private TableColumn<CarsData, String> empNumberForeign;
    
    
    SignInController name = new SignInController();
    private DBConnection con;
    private ObservableList<EmployeeData> data;
    private ObservableList<CarsData> carData;
    private String emplTable = "SELECT * FROM employees";
    private String carsTable = "SELECT * FROM cars";
    @FXML
    private TableColumn<CarsData, String> carID;
    @FXML
    private AnchorPane loadCars_Pane;
    @FXML
    private AnchorPane addCar_pane;
    @FXML
    private JFXButton restart1;
    @FXML
    private JFXButton addTest1;
    @FXML
    private Button closeAddCar;
    @FXML
    private JFXTextField carID_input;
    @FXML
    private JFXTextField model_Input;
    @FXML
    private JFXTextField type_Input;
    @FXML
    private JFXTextField bookings_Input;
    @FXML
    private JFXTextField doa_Input;
    @FXML
    private JFXTextField empNumber_Input;
    @FXML
    private AnchorPane deleteCar_pane;
    @FXML
    private JFXTextField carID_input1;
    @FXML
    private JFXButton restart11;
    @FXML
    private JFXButton delete;
    @FXML
    private Button closeAddCar1;
    @FXML
    private FontAwesomeIconView loginScreen;
    @FXML
    private JFXTextField lcode_test;
    @FXML
    private Text invoice_cName;
    @FXML
    private Text invoice_testNum;
    @FXML
    private Text invoice_price;
    @FXML
    private Text invoice_date;
    @FXML
    private Text invoice_AdminName;
    @FXML
    private AnchorPane invoice_Pane;
    @FXML
    private AnchorPane payment_Pane;
    @FXML
    private JFXTextField pay_field;
    @FXML
    private JFXButton addTest2;
    @FXML
    private JFXTextField identityNumber_confirm;
    @FXML
    private TextField id_invoiceTest;
   
   
 

    /**
     * Initializes the controller class.
     * set the home pane to the front and hides the others
     * initialize the database connection between this class and the database connector class
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        home_pane.toFront();
        username.setText(name.getUsername());
        this.con = new DBConnection();
    }  
    
    //swaps the panes on the control panel depending on the button clicked on the navigational system
    @FXML
    private void handleAction(MouseEvent event) throws Exception{
        
        if(event.getSource() == dashboard_btn){
            home_pane.toFront();
        }
        
        if(event.getSource() == viewEmployees_btn){
            viewEmployees_Pane.toFront();
        }
        
        if(event.getSource() == viewCars_btn){
            viewCars_Pane.toFront();
            loadCars_Pane.toFront();
        }
        
        if(event.getSource() == addCars){
            viewCars_Pane.toFront();
            addCar_pane.toFront(); 
        }
         if(event.getSource() == closeAddCar){
            addCar_pane.toBack();
            loadCars_Pane.toFront();
        }
         if(event.getSource() == closeAddCar1){
            addCar_pane.toBack();
            loadCars_Pane.toFront();
        }
        
        if(event.getSource() == bookTest_btn){
            bookTest_Pane.toFront();
        }
        
        if(event.getSource() == deleteCars){
            viewCars_Pane.toFront();
            deleteCar_pane.toFront();
        }
        
        if(event.getSource() == payment_btn){
            payment_Pane.toFront();
        }
        
        if(event.getSource() == invoices_btn){
            invoice_Pane.toFront();
            
        }
    }

    //clears the data entered on the fields for the booking of a test
    @FXML
    private void clearTest(ActionEvent event) {
        
        fname_test.setText(null);
        lname_test.setText(null);
        email_test.setText(null);
        id_test.setText(null);
        
    }
    
    //This is the functionality of the invoice, basically runs few queries and gets bookings data from the database and generates an invoice for you
    //With time we can try to research and add a print functionality
    @FXML
    public void invoiceForTest() throws Exception{
      
     
      //The following strings contain the column names on the database for the purpose of retriving infomation
      String id = "id";
      String customerName="fname";
      //this is the id you use to get your invoice
      String identityy = id_invoiceTest.getText();
      String price = "price";
      String administrator = "administrator";
      String time = "time";
       
      
      //This creates an instance object called invoice of the class GetInvoiceDetails
      //this class allows us to use code reuse to get the individual columns from the database so that we can use them here
      GetInvoiceDetails invoice = new GetInvoiceDetails();
      
      //This sets the information from the database into the placeholder texts we have in our graphical user interface
      //this is strictly for the invoice pane we created.
      invoice_cName.setText(invoice.getValue(customerName, identityy));
      invoice_testNum.setText(invoice.getValue(id, identityy));
      invoice_price.setText("ZAR " + invoice.getValue(price ,identityy));
      invoice_date.setText(invoice.getValue(time, identityy));
      invoice_AdminName.setText(invoice.getValue(administrator, identityy));
      
    }
    
    
    //adds a booking details of a client into the database
    @FXML
    private void RegisterATest(ActionEvent event) {
    
        //sets 
       String sqlInsert = "INSERT INTO bookings(fname, lname, email, identityNumber, lcode) VALUES (?,?,?,?,?)";
        
        try{
            //creates a connection between the class and the database
            Connection conn = DBConnection.getConnection();
            //creates a statement holding the query
            PreparedStatement stm = conn.prepareStatement(sqlInsert);

            stm.setString(1, this.fname_test.getText());
            stm.setString(2, this.lname_test.getText());
            stm.setString(3, this.email_test.getText());
            stm.setString(4, this.id_test.getText());
            stm.setString(5, this.lcode_test.getText());
     
            stm.execute();
            conn.close();
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Car Successfully Added");
            alert.showAndWait();

            
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }   

    //Retrieves data about cars from the database and populate it on the control panel table view for view cars
    @FXML
    private void loadCars(ActionEvent event) throws Exception {
        
        try{
            Connection conn = DBConnection.getConnection();
            this.carData = FXCollections.observableArrayList();
            ResultSet carsRS = conn.createStatement().executeQuery(carsTable);
            while(carsRS.next()){
                this.carData.add(new CarsData(carsRS.getString(1), carsRS.getString(2), carsRS.getString(3), carsRS.getString(4), carsRS.getString(5), carsRS.getString(6)));
            }
        }
        catch(SQLException e){
            System.err.println("error: " + e);
        }
        
        this.carID.setCellValueFactory(new PropertyValueFactory<CarsData, String>("carId"));
        this.model.setCellValueFactory(new PropertyValueFactory<CarsData, String>("model"));
        this.type.setCellValueFactory(new PropertyValueFactory<CarsData, String>("type"));
        this.bookings.setCellValueFactory(new PropertyValueFactory<CarsData, String>("bookings"));
        this.doa.setCellValueFactory(new PropertyValueFactory<CarsData, String>("doa"));
        this.empNumberForeign.setCellValueFactory(new PropertyValueFactory<CarsData, String>("empNumberForeign"));
        this.carsDataTable.setItems(null);
        this.carsDataTable.setItems(this.carData);
        
    }
    //adds car to the database
    @FXML
    public void addCarToDatabase() throws Exception{
         String sqlInsert = "INSERT INTO cars(carID, model, type, bookings, dateAvailable, empNumber) VALUES (?,?,?,?,?,?)";

        try{
            Connection conn = DBConnection.getConnection();
            PreparedStatement stm = conn.prepareStatement(sqlInsert);

            stm.setString(1, this.carID_input.getText());
            stm.setString(2, this.model_Input.getText());
            stm.setString(3, this.type_Input.getText());
            stm.setString(4, this.bookings_Input.getText());
            stm.setString(5, this.doa_Input.getText());
            stm.setString(6, this.empNumber_Input.getText());
            
            if(isEmpNumber(empNumber_Input.getText()) == true){
                stm.execute();
                conn.close();
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Car Successfully Added");
                alert.showAndWait();
            }
            else{
               Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid Employee Number");
               alert.showAndWait(); 
            }
           
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }
    
    //Checks if the employee number exists in our database
    public boolean isEmpNumber(String empNumber) throws Exception{
        
      
        ResultSet rs = null;
        String sqls = "SELECT * FROM cars WHERE empNumber = ? ";
        try{
            Connection connc = DBConnection.getConnection();
            PreparedStatement pr = null;
            pr = connc.prepareStatement(sqls);
            pr.setString(1, empNumber);
            
            rs = pr.executeQuery();
            
            boolean marven;
            
            if(rs.next()){
                return true;
            }
            return false;
        }
        catch(SQLException ex){
            return false;
        }
        finally{
                rs.close();
        }
    } 
    
    //Checks if the identity number exists in our database
    public boolean isIdentityNumber(String identity) throws Exception{
        
      
        ResultSet rs = null;
        String sqls = "SELECT * FROM bookings WHERE identityNumber = ? ";
        try{
            Connection connc = DBConnection.getConnection();
            PreparedStatement pr = null;
            pr = connc.prepareStatement(sqls);
            pr.setString(1, identity);
            
            rs = pr.executeQuery();
            
            boolean marven;
            
            if(rs.next()){
                return true;
            }
            return false;
        }
        catch(SQLException ex){
            return false;
        }
        finally{
                rs.close();
        }
    } 
    //Takes data about employees from the database and populate it on the control panel table view for employees
   
    //this takes the information from the database and loads it on the table view we created on our employees pane
    @FXML
    private void loadEmployees(ActionEvent event) throws Exception{
        
        //connects to the database and get the information
        try{
            Connection connection = DBConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            ResultSet rs = connection.createStatement().executeQuery(emplTable);
            while(rs.next()){
                this.data.add(new EmployeeData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)));
            }
        }
        catch(SQLException e){
            System.err.println("Error : " + e);
        }
        
        //populates the  table view
        this.empNumbe.setCellValueFactory(new PropertyValueFactory<EmployeeData, String>("empNumber"));
        this.fname.setCellValueFactory(new PropertyValueFactory<EmployeeData, String>("fname"));
        this.lname.setCellValueFactory(new PropertyValueFactory<EmployeeData, String>("lname"));
        this.email.setCellValueFactory(new PropertyValueFactory<EmployeeData, String>("email"));
        this.duties.setCellValueFactory(new PropertyValueFactory<EmployeeData, String>("duties"));
        this.dob.setCellValueFactory(new PropertyValueFactory<EmployeeData, String>("dob"));
        this.employees_table.setItems(null);
        this.employees_table.setItems(this.data);
        
    }

    //clears the data entered in the text fields we have
    @FXML
    private void clearBookings(ActionEvent event) {
        
        carID_input.setText(null);
        model_Input.setText(null);
        type_Input.setText(null);
        bookings_Input.setText(null);
        doa_Input.setText(null);
        empNumber_Input.setText(null);
    }

    //deletes car from the database, for this to happen you need the car id
    @FXML
    private void deleteCarToDatabase(ActionEvent event) throws Exception {
        String sql = "DELETE FROM cars WHERE carID = ?";
        
        try{
            Connection delete = DBConnection.getConnection();
            PreparedStatement stm = delete.prepareStatement(sql);
            stm.setString(1, carID_input1.getText());
            stm.executeUpdate();
            delete.close();
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Employee Number is no");
            alert.showAndWait();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }

    //this takes you back to login screen in case you need to register a user or login using a different administrator account
    @FXML
    private void loginMenu(MouseEvent event) {
        Stage stage = (Stage)this.loginScreen.getScene().getWindow();
        stage.close();
         try{
                    Stage drivingSchool = new Stage();
                    FXMLLoader drivingLoader = new FXMLLoader();
                    Parent root = (Parent)drivingLoader.load(getClass().getResource("/ovcsdrivingschool/main/login.fxml").openStream());

                    loginController control = (loginController)drivingLoader.getController();

                    Scene scene = new Scene(root);
                    drivingSchool.initStyle(StageStyle.TRANSPARENT);
                    scene.setFill(Color.TRANSPARENT);
                    //scene.getStylesheets().setAll(getClassLoader().getResource("/ovcsdrivingschool/controlpanel/controlpanel.css").toExternalForm());
                    scene.getStylesheets().setAll(getClass().getResource("/ovcsdrivingschool/main/main.css").toExternalForm());
       
                    drivingSchool.setScene(scene);
                    
                
                    drivingSchool.show();
                }
                catch(IOException ex){
                    ex.printStackTrace();
                }
    }

    
    //The customer does the payment here for the booking he/she has made
    @FXML
    private void pay(ActionEvent event) throws Exception {
       //The administrator's name and the time of transaction are stored in the database database first
       setAdministrator();
       setTime();
       //The SQL Query is declared here
       String sqlInsert = "UPDATE bookings SET price = ?  WHERE identityNumber = ?";
       
        try{
            //Connection to the database is made here
            Connection conn = DBConnection.getConnection();
            //We take the query and make a statement with it usign the values (price field which is the money you pay) and the id number of the client
            PreparedStatement stm = conn.prepareStatement(sqlInsert);

            stm.setString(1, pay_field.getText());
            stm.setString(2, identityNumber_confirm.getText());
            
            //this checks if the identity of the client exist in the system before any payment can be made, if it doesn't exit you can't make the payment
            if(isIdentityNumber(identityNumber_confirm.getText()) == true){
                stm.execute();
                conn.close();
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Payment Made successfully");
                alert.showAndWait();
                
            }
            else{
               Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid Identity Number");
               alert.showAndWait(); 
            }
         
        }
        catch(SQLException ex){
            System.out.println("Error finilizing the payment: " + ex.getMessage());
        }
    }
    
    //The aministrator's name is captured and stored in the bookings table on our database
    public void setAdministrator() throws Exception{
        try{
            Connection admin = DBConnection.getConnection();
            PreparedStatement ad = admin.prepareStatement("UPDATE bookings SET administrator = ? WHERE identityNumber = ?");
            String usr = name.getUsername();
            ad.setString(1, usr);
            ad.setString(2, identityNumber_confirm.getText());
            
            if(isIdentityNumber(identityNumber_confirm.getText()) == true){
                ad.execute();
                admin.close();
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Administrator Set Successfully");
                alert.showAndWait();
            }
            else{
               Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid Identity Number");
               alert.showAndWait(); 
            }
        }
        catch(SQLException ex){
            System.out.println("Error setting admin: " + ex.getMessage());
        }
    } 
    
    //the current time and date is taken from the system and stored in a database
     public void setTime() throws Exception{
        try{
            Connection admin = DBConnection.getConnection();
            PreparedStatement ad = admin.prepareStatement("UPDATE bookings SET time = ? WHERE identityNumber = ?");
             //Gets the time from the System and print it to the invoice
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
                Date date = new Date(System.currentTimeMillis());
                String time = formatter.format(date).toString();
             //
            ad.setString(1, time);
            ad.setString(2, identityNumber_confirm.getText());
            ad.execute();
            admin.close();
        }
        catch(SQLException ex){
            System.out.println("Error setting Time: " + ex.getMessage());
        }
    } 
}
