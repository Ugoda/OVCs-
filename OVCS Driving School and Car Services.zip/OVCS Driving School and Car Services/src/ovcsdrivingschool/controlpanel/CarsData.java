
package ovcsdrivingschool.controlpanel;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class CarsData {
    
    //creates private string property which cannot be changed
    private final StringProperty carID;
    private final StringProperty model;
    private final StringProperty type;
    private final StringProperty bookings;
    private final StringProperty doa;
    private final StringProperty empNumberForeign;
    
    
    //this is a constructor with some parameters
    public CarsData(String carID, String model, String type, String bookings, String doa, String empNumberForeign){
        
        this.carID = new SimpleStringProperty(carID);
        this.model = new SimpleStringProperty(model);
        this.type = new SimpleStringProperty(type);
        this.bookings = new SimpleStringProperty(bookings);
        this.doa = new SimpleStringProperty(doa);
        this.empNumberForeign = new SimpleStringProperty(empNumberForeign);
    }
    //below we have our mutator and accessor methods that can be used in other classes
    
    //
    public String getCarID(){
        return this.carID.get();
    }
    
    public StringProperty carIdProperty(){
        return carID;
    }
    
    public void setCarID(String carID){
        this.carIdProperty().set(carID);
    }
    
    public String getModel(){
        return this.model.get();
    }
    
    public StringProperty modelProperty(){
        return model;
    }
    
    public void setModel(String model){
        this.model.set(model);
    }
    
    public String getType(){
        return this.type.get();
    }
    
    public StringProperty typeProperty(){
        return type;
    }
    
    public void setType(String type){
        this.type.set(type);
    }
    
    public String getBookings(){
        return this.bookings.get();
    }
    
    public StringProperty bookingsProperty(){
        return bookings;
    }
    
    public void setBookings(String bookings){
        this.bookings.set(bookings);
    }
    
    public String getDOA(){
        return this.doa.get();
    }
    
    public StringProperty doaProperty(){
        return doa;
    }
    
    public void setDOA(String doa){
        this.doa.set(doa);
    }
    
    public String getEmpNumberForeign(){
        return this.empNumberForeign.get();
    }
    
    public StringProperty empNumberForeignProperty(){
        return empNumberForeign;
    }
    
    public void setEmpNumberForeign(String empNumberForeign){
        this.empNumberForeign.set(empNumberForeign);
    }
}
