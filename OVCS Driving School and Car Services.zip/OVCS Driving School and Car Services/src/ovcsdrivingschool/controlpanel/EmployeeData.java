
package ovcsdrivingschool.controlpanel;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


//this is the class that sets up the data from the database into the tableview in the gui....but
//this class does not mean its connecting to the database, no. it just prepare the variables through the constructor to be ready for use when called
//we also have the mutator and accessor methods. the same thing goes for the Employee Data
public class EmployeeData {
    
    private final StringProperty empNumber;
    private final StringProperty fname;
    private final StringProperty lname;
    private final StringProperty email;
    private final StringProperty duties;
    private final StringProperty dob;
    
    
    public EmployeeData(String empNumber, String fname, String lname, String email, String duties, String dob){
        
         this.empNumber = new SimpleStringProperty(empNumber);
         this.fname= new SimpleStringProperty(fname);
         this.lname = new SimpleStringProperty(lname);
         this.email = new SimpleStringProperty(email);
         this.duties = new SimpleStringProperty(duties);
         this.dob = new SimpleStringProperty(dob);
    }
    
    public String getEmpnumber(){
        return empNumber.get();
    }
    
    public StringProperty empNumberProperty(){
        return empNumber;
    }
    
    public void setEmpNumber(String empNumber){
        this.empNumber.set(empNumber);
    }
    
    public String getFname(){
        return fname.get();
    }
    
    public StringProperty fnameProperty(){
        return fname;
    }
    
    public void setFname(String fname){
        this.fname.set(fname);
    }
    
    public String getLname(){
        return lname.get();
    }
    
    public StringProperty lnameProperty(){
        return lname;
    }
    
    public void setLname(String lname){
        this.lname.set(lname);
    }
    
    public String getEmail(){
        return email.get();
    }
    
    public StringProperty emailProperty(){
        return email;
    }
    
    public void setEmail(String email){
        this.email.set(email);
    }
    
    public String getDuties(){
        return duties.get();
    }
    
    public StringProperty dutiesProperty(){
        return duties;
    }
    
    public void setDuties(String duties){
        this.duties.set(duties);
    }
    
    public String getDOB(){
        return dob.get();
    }
    
    public StringProperty dobProperty(){
        return dob;
    }
    
    public void setDOB(String dob){
        this.dob.set(dob);
    }
}
