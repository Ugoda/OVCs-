
package ovcsdrivingschool.controlpanel;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import ovcs.databae.connection.DBConnection;

//takes input out of the database, the colomn wanted and the value of the id is not set
public class GetInvoiceDetails {
    
    //col and identity are placeholders that are parsed through in another class that needs a specific data from the database
    //we are doing this so that we don't rewrite our code all the time
    public String getValue(String col, String identity) throws Exception{
       String sql = "SELECT "+ col +" FROM bookings WHERE identityNumber = '"+identity+"'";
       String value = ""; 
       try{
            Connection conn = DBConnection.getConnection();
            
            ResultSet rs = conn.createStatement().executeQuery(sql);
            
            if(rs.next()){
                value =  rs.getString(col);
                
                return value;
            }
            
            conn.close();
        }
        catch(SQLException e){
            System.err.println("error: " + e);
        }
       return value;
    }
    
    
}
