
package ovcs.database.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import ovcs.databae.connection.DBConnection;



public class LoginModel {
    
    Connection connection;
    
    /*
    /The constructor below initialize the variable connection to getConnection Method in 
    /the database Connection
    */
    public LoginModel(){
        
        try{
            this.connection = DBConnection.getConnection();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        
        if(this.connection == null){
            System.exit(1);
        }
    }
    
    //this method will check if the database is connected to the application or not and return the connection
    public boolean isDatabaseConnected(){
       
        return this.connection != null;
    
    }
    
    //here the application reads from the database if the user entered fields match those in the database
    public boolean isLogin(String user, String pass) throws Exception{
        
        PreparedStatement pr = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM login WHERE username = ? and password = ?";
        try{
            pr = this.connection.prepareStatement(sql);
            pr.setString(1, user);
            pr.setString(2, pass);
            
            rs = pr.executeQuery();
            
            boolean marven;
            
            if(rs.next()){
                return true;
            }
            return false;
        }
        catch(SQLException ex){
            return false;
        }
        finally{
            {
                pr.close();
                rs.close();
            }
        }
    }  
}
