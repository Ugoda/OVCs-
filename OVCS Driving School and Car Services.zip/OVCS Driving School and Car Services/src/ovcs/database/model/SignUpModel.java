
package ovcs.database.model;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import ovcs.databae.connection.DBConnection;


public class SignUpModel {
    
    
   Connection connection;
    //creates a connection in the constructor of the class
    public SignUpModel(){
      
        try{
             this.connection = DBConnection.getConnection();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }
    
    //gets input from another class(cpanelBackupController) to use for sign-up 
    public void signUp(String username, String password) throws Exception{
        
       
        try{
     
          
             Statement statement = this.connection.createStatement();
             
             if(username.equals("") && password.equals("")){
                Alert alert = new Alert(AlertType.ERROR, "Your fields are empty, please fill the fields");
                alert.showAndWait();
             }
             else
                 if(username.equals("")){
                     Alert alert = new Alert(AlertType.ERROR, "Username field is empty.. \n\nPlease fill this field before you can continue");
                    alert.showAndWait();
             }
              else
                 if(password.equals("")){
                     Alert alert = new Alert(AlertType.ERROR, "Password field is empty.. \n\nPlease fill this field before you can continue");
                    alert.showAndWait();
             }
             else{
                int status = statement.executeUpdate("insert into login(username, password) values('"+username+"','"+password+"')");
                if(status > 0){
                System.out.println("User registered");
                
                Alert alert = new Alert(AlertType.INFORMATION, "Registration Completed Successfully \n\nYou can now GoTo Sign IN");
                alert.showAndWait();
            } 
        }
            
            
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }
    
}
