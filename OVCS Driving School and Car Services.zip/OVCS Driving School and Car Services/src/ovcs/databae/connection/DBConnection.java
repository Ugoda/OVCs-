
package ovcs.databae.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnection {
    

    private static final String sqcon = "jdbc:sqlite:ovcs.sqlite";
    public static Connection getConnection() throws SQLException {
        
        try{
            Class.forName("org.sqlite.JDBC");
            return DriverManager.getConnection(sqcon);
        }
        catch(ClassNotFoundException ex){
            
            ex.printStackTrace();
        }
        return null;
    }
}

