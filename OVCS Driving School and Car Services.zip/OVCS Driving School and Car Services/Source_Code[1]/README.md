### Game source Code
* The main method is in Puzzle.java and you can (probably) work your way from there :D  
* Most of the GUI is auto-generated with netbeans GUI Builder (thus the GUI.form file)
